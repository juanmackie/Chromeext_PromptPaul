/**
 * @fileoverview Chat Interface for Prompt Paul Chrome Extension
 *
 * This module handles the side panel chat interface including:
 * - Message sending and receiving
 * - Streaming API response handling
 * - Quick actions (load content, summarize, explain)
 * - Pinned custom instructions
 * - Copy functionality for messages
 * - Voice input support
 *
 * @module chat
 * @requires ./themeUtils.js
 * @requires ./loadingManager.js
 */
import { setupThemeToggle } from './themeUtils.js';
import { loadingManager } from './loadingManager.js';
import { normalizeToolChoice } from './src/utils/toolChoiceBuilder.js';
import { chatUI } from './src/chat/ChatUI.js';
import { attachCopyListeners, postProcessRenderedContent } from './src/chat/ChatClipboard.js';
import {
  getApiConfig,
  getTools,
  startRun,
  executeRun,
  abortRun,
  selectOptimalProfile,
} from './src/chat/ChatAPI.js';
import {
  isWebSearchEnabled,
  initWebSearchToggle,
  buildFinalResponseBody,
  classifyToolExecutionResult,
} from './src/chat/ChatGrounding.js';
import {
  MediaType,
  validateMediaData,
  getMediaAnalysisPrompt,
  prepareMediaContent,
  hasValidMediaData,
  getMediaDisplayName,
  supportsVisionAnalysis,
} from './src/chat/ChatMedia.js';
import { StreamStateManager } from './src/chat/ChatStream.js';
import { debounce } from './src/utils/debounce.js';
import { resolveDomContextBudget, fitTextToTokenBudget } from './src/utils/contextBudget.js';
import { extractPdfText } from './src/utils/pdfExtractor.js';
import { friendlyRuntimeErrorMessage } from './src/utils/runtimeErrors.js';
import { RUN_STATES, setRunState } from './src/utils/runState.js';
import { chatComposer } from './src/chat/ChatComposer.js';
import { escapeHtml, renderMarkdown } from './src/utils/domSanitizer.js';
import {
  buildExplainPrompt,
  buildSummarizePrompt,
  PROOFREAD_PROMPT,
  composeUserPrompt,
} from './src/prompts.js';
import { renderSiteSuggestions, executePresetAnalysis } from './src/chat/ChatPageActions.js';

// ── Lazy Module Loaders ───────────────────────────────────────────
// Non-critical modules are loaded on demand to reduce initial startup cost.

/** @type {import('./src/chat/ChatSkills.js') | null} */
let _chatSkillsModule = null;

/**
 * Lazy-load the ChatSkills module.
 * Loaded on first "/" keypress or skill command invocation.
 * @returns {Promise<import('./src/chat/ChatSkills.js')>}
 */
async function getChatSkills() {
  if (!_chatSkillsModule) {
    _chatSkillsModule = await import('./src/chat/ChatSkills.js');
  }
  return _chatSkillsModule;
}

/** @type {import('./src/chat/ChatVoice.js') | null} */
let _chatVoiceModule = null;

/**
 * Lazy-load the ChatVoice module.
 * Loaded on first voice-toggle button click.
 * @returns {Promise<import('./src/chat/ChatVoice.js')>}
 */
async function getChatVoice() {
  if (!_chatVoiceModule) {
    _chatVoiceModule = await import('./src/chat/ChatVoice.js');
  }
  return _chatVoiceModule;
}

/** @type {import('./src/chat/ChatAPI.js') | null} */
let _chatApiModule = null;

/**
 * Lazy-load the ChatAPI module for fresh config reads.
 * @returns {Promise<import('./src/chat/ChatAPI.js')>}
 */
async function getChatApi() {
  if (!_chatApiModule) {
    _chatApiModule = await import('./src/chat/ChatAPI.js');
  }
  return _chatApiModule;
}

/** @type {import('./src/chat/ChatMedia.js') | null} */
let _chatMediaModule = null;

/**
 * Lazy-load the ChatMedia module for media-heavy operations.
 * @returns {Promise<import('./src/chat/ChatMedia.js')>}
 */
async function getChatMedia() {
  if (!_chatMediaModule) {
    _chatMediaModule = await import('./src/chat/ChatMedia.js');
  }
  return _chatMediaModule;
}

/**
 * Error boundary wrapper for async operations.
 * Provides consistent error handling with user feedback.
 * @param {Function} asyncFn - The async function to wrap
 * @param {Object} options - Error handling options
 * @param {string} options.context - Description of the operation for logging
 * @param {boolean} options.showToast - Whether to show error toast (default: true)
 * @param {string} options.fallbackMessage - Custom error message if function fails
 * @returns {Promise<any>} The result of the async function or undefined on error
 */
async function handleAsyncError(asyncFn, options = {}) {
  const { context = 'Operation', showToast = true, fallbackMessage } = options;
  try {
    return await asyncFn();
  } catch (error) {
    const errorMessage = fallbackMessage || `${context} failed: ${error.message}`;
    console.error(`Chat Error [${context}]:`, error);
    if (showToast) {
      loadingManager.showToast(errorMessage, 'error');
    }
    return undefined;
  }
}

function renderMarkdownContent(markdown) {
  return renderMarkdown(markdown);
}

function formatUserMessageForDisplay(message) {
  const text = String(message || '');
  const firstLine = text.split(/\r?\n/)[0];
  const maxInlineLength = 240;
  if (firstLine.length <= maxInlineLength) return firstLine;
  return `${firstLine.slice(0, maxInlineLength)}…`;
}

document.addEventListener('DOMContentLoaded', () => {
  const chatArea = document.getElementById('chat-area');
  const userInput = document.getElementById('user-input');
  const sendButton = document.getElementById('send-button');
  const selectedTextDiv = document.getElementById('selectedText');
  const selectedTextStrip = document.getElementById('selected-text-strip');
  const selectedTextSnippet = document.getElementById('selected-text-snippet');
  const selectedTextRemoveButton = document.getElementById('selected-text-remove-button');
  const instructionInput = document.getElementById('instructionInput');
  const submitBtn = document.getElementById('submitBtn');
  const chatMainArea = document.getElementById('chat-main-area');
  const oneoffInstructionArea = document.getElementById('oneoff-instruction-area');

  // Quick Actions Sidebar Elements
  const addPageButton = document.getElementById('add-page-button');
  const analyzeButton = document.getElementById('analyze-button');
  const analyzeDropdown = document.getElementById('analyze-dropdown');
  const proofreadButton = document.getElementById('proofread-button');
  const explainButton = document.getElementById('explain-button');

  // Configure marked with highlight.js for syntax highlighting
  if (typeof marked !== 'undefined' && typeof hljs !== 'undefined') {
    marked.setOptions({
      highlight: function (code, lang) {
        if (lang && hljs.getLanguage(lang)) {
          if (isResponseBusy()) {
            loadingManager.showToast('A response is already in progress', 'warning');
            return;
          }

          submitBtn.disabled = true;

          try {
            return hljs.highlight(code, { language: lang }).value;
          } catch (_) {
            return code;
          }
        }
        return code;
      },
    });
  }

  // Initialize chatUI DOM references
  chatUI.initialize();
  const pinnedActionsContainer = document.getElementById('pinned-actions-container');

  // Preset registry for analysis modes
  const PRESET_MODES = {
    summary: {
      key: 'summary',
      label: 'Summary',
      icon: 'auto_awesome',
      prompt: buildSummarizePrompt('content'),
    },
    tldr: {
      key: 'tldr',
      label: 'TL;DR',
      icon: 'short_text',
      prompt: 'Provide a very brief TL;DR (3-4 sentences) of this content.',
    },
    technical: {
      key: 'technical',
      label: 'Technical',
      icon: 'code',
      prompt: 'Provide a technical deep dive of this content.',
    },
    proofread: {
      key: 'proofread',
      label: 'Proofread',
      icon: 'spellcheck',
      prompt: PROOFREAD_PROMPT,
    },
    executive: {
      key: 'executive',
      label: 'Executive',
      icon: 'assignment',
      prompt: 'Provide an executive summary of this content.',
    },
  };

  let lastUsedPreset = 'summary'; // Default preset mode
  let lastLoadedPageContext = null;

  /**
   * Helper to execute a preset analysis.
   */
  async function executePreset(presetKey, loadingText, successText) {
    await executePresetAnalysis({
      presetKey,
      loadingText,
      successText,
      presetModes: PRESET_MODES,
      chatMainArea,
      oneoffInstructionArea,
      makeApiCall,
      loadingManager,
      chatUI,
      showSiteSuggestions,
    });
  }

  /**
   * Helper to execute a specific preset mode.
   */
  async function executePagePresetMode(modeKey) {
    const preset = PRESET_MODES[modeKey];
    if (!preset) {
      console.warn('Unknown preset mode:', modeKey);
      return;
    }
    executePreset(modeKey, `Generating ${preset.label}...`, `${preset.label} started`);
  }

  async function showSiteSuggestions(url, platform = null, platformInfo = null) {
    await renderSiteSuggestions({
      url,
      platform,
      platformInfo,
      chatMainArea,
      oneoffInstructionArea,
      makeApiCall,
      chatAreaElement: document.getElementById('chat-area'),
    });
  }

  function activateSelectedTextActionView() {
    chatMainArea.classList.remove('hidden');
    oneoffInstructionArea.classList.add('hidden');
  }

  function clearSelectedTextState() {
    selectedText = null;
    selectedTextDiv.textContent = '';
    refreshSelectedTextActionState();
  }

  function getSelectedText() {
    return String(selectedText || '').trim();
  }

  function getSelectedTextForAction(actionLabel) {
    const text = getSelectedText();
    if (!text) {
      loadingManager.showToast(`Please select text first to ${actionLabel}.`, 'warning');
      return null;
    }

    return text;
  }

  function hasConversation() {
    const history = streamState.getConversationHistory();
    return Array.isArray(history) && history.length > 0;
  }

  function updateSelectedTextActionButtons() {
    // Sidebar actions run on the sticky selection OR, once a conversation
    // exists, as a follow-up on the previous response.
    const canRun = Boolean(getSelectedText()) || hasConversation();
    [analyzeButton, proofreadButton, explainButton, analyzeDropdown, customPromptsDropdown].forEach(
      (button) => {
        if (!button) return;
        button.disabled = !canRun;
        button.title = canRun
          ? button.dataset.enabledTitle || button.title
          : 'Select text first to run this action';
      }
    );
  }

  // Show/hide the dismissible selected-text chip in the chat input area so the
  // sticky selection is never hidden state.
  function updateSelectedTextChip() {
    if (!selectedTextStrip) return;
    const text = getSelectedText();
    if (text) {
      if (selectedTextSnippet) {
        selectedTextSnippet.textContent = text.length > 140 ? `${text.slice(0, 140)}…` : text;
      }
      selectedTextStrip.hidden = false;
    } else {
      selectedTextStrip.hidden = true;
      if (selectedTextSnippet) selectedTextSnippet.textContent = '';
    }
  }

  function refreshSelectedTextActionState() {
    updateSelectedTextActionButtons();
    updateSelectedTextChip();
  }

  // Compose the prompt request for a sidebar action: attach sticky selected text
  // as structured context when present, otherwise fall back to a follow-up on
  // the existing conversation. Returns null (and warns) when there is neither.
  function composeActionPrompt(basePrompt, actionLabel) {
    const text = getSelectedText();
    if (text) {
      return {
        instruction: basePrompt,
        context: {
          type: 'selected_text',
          text,
        },
      };
    }
    if (hasConversation()) {
      return {
        instruction: basePrompt,
        context: {
          type: 'previous_response',
        },
      };
    }
    // Nothing selected and no conversation to build on — emit standard warning.
    getSelectedTextForAction(actionLabel);
    return null;
  }

  async function runSelectedTextPrompt(prompt, toolChoice, actionLabel) {
    const composed = composeActionPrompt(prompt, actionLabel);
    if (composed === null) {
      return false;
    }

    activateSelectedTextActionView();
    await makeApiCall(composed, toolChoice);
    // Keep the selection sticky so further actions can run on the same text.
    return true;
  }

  async function executeSelectedTextMode(modeKey) {
    const preset = PRESET_MODES[modeKey];
    if (!preset) {
      console.warn('Unknown preset mode:', modeKey);
      return false;
    }

    const composed = composeActionPrompt(preset.prompt, `run ${preset.label}`);
    if (composed === null) {
      return false;
    }

    lastUsedPreset = modeKey;
    activateSelectedTextActionView();
    await makeApiCall(composed, 'auto');
    // Keep the selection sticky so further actions can run on the same text.
    return true;
  }

  async function executeSelectedTextInstruction(instruction) {
    const actionName = instruction.name || 'this prompt';
    const composed = composeActionPrompt(instruction.content, `run ${actionName}`);
    if (composed === null) {
      return false;
    }

    activateSelectedTextActionView();
    await makeApiCall(composed, normalizeToolChoice(instruction.tool_choice));
    // Keep the selection sticky so further actions can run on the same text.
    return true;
  }

  // Inserts already-extracted page content into the chat context. Shared by the
  // normal DOM path and the PDF path (which supplies a response-shaped object).
  function applyLoadedPageContent(response) {
    let sourceInfo = response.title;
    if (response.siteName) sourceInfo = `${response.title} (${response.siteName})`;
    if (response.byline) sourceInfo += ` by ${response.byline}`;

    chatUI.addLoadedContentMessage(sourceInfo, response.content);

    showSiteSuggestions(response.url, response.platform, response.platformInfo);

    lastLoadedPageContext = {
      url: response.url,
      platform: response.platform || null,
      readStrategy: response.readStrategy || 'auto',
      extractionSource: response.extractionSource || 'auto',
      extractionReason: response.extractionReason || '',
      hasScreenshot: Boolean(response.screenshot),
      hasMediaContext: Boolean(streamState.getMediaData()),
    };

    composer.setPageContext({
      details: `${response.url}${fitted.truncated ? ' (trimmed)' : ''}`,
    });
    syncChatAreaHeight();

    const budget = resolveDomContextBudget({
      modelId: null,
      userMessage: '',
      contextCount: 1,
      fileAttachmentCount: streamState.getMediaData() ? 1 : 0,
    });
    const fitted = fitTextToTokenBudget(response.content, budget.perContextDomTokens);
    const contextNotes = [];
    if (lastLoadedPageContext.readStrategy !== 'auto') {
      contextNotes.push(`Read strategy: ${lastLoadedPageContext.readStrategy}.`);
    }
    if (
      lastLoadedPageContext.extractionSource &&
      lastLoadedPageContext.extractionSource !== 'auto'
    ) {
      const extractionNote = `Extraction source: ${lastLoadedPageContext.extractionSource}.`;
      contextNotes.push(
        lastLoadedPageContext.extractionReason
          ? `${extractionNote} ${lastLoadedPageContext.extractionReason}`
          : extractionNote
      );
    }
    if (lastLoadedPageContext.hasScreenshot) {
      contextNotes.push('Visual screenshot context is available.');
    }
    if (lastLoadedPageContext.hasMediaContext) {
      contextNotes.push('Additional media attachment context is active.');
    }

    const loadedContextInstruction = [
      `I have loaded the content from the page "${response.title}" (${response.url}).`,
      `Source: ${response.siteName || 'Unknown'}`,
      `Author: ${response.byline || 'Unknown'}`,
      `Platform: ${response.platform || 'unknown'}`,
      contextNotes.length ? `Context notes: ${contextNotes.join(' ')}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    streamState.getConversationHistory().push({
      role: 'user',
      content: composeUserPrompt({
        instruction: loadedContextInstruction,
        context: {
          type: 'page_content',
          text: fitted.text,
        },
      }),
    });

    chatMainArea.classList.remove('hidden');
    oneoffInstructionArea.classList.add('hidden');
    userInput.focus();
    const statusParts = ['Content loaded.'];
    if (fitted.truncated) {
      statusParts.push(
        `Trimmed to fit context budget (${fitted.includedTokens}/${fitted.originalTokens} estimated tokens).`
      );
    }
    chatUI.addMessage('System', statusParts.join(' '));
  }

  // Reads a PDF in the chat page via pdf.js and feeds the text into the chat.
  async function loadPdfContent(response, loadingToast) {
    loadingManager.hideToast(loadingToast);
    const pdfToast = loadingManager.showToast('Reading PDF…', 'info');
    try {
      const { text, title, numPages, truncated } = await extractPdfText(response.pdfUrl);
      loadingManager.hideToast(pdfToast);
      applyLoadedPageContent({
        success: true,
        content: text,
        title: title || response.title || 'PDF document',
        siteName: 'PDF document',
        url: response.pdfUrl,
        platform: 'pdf',
        platformInfo: null,
        readStrategy: 'auto',
      });
      if (truncated) {
        chatUI.addMessage(
          'System',
          `Note: only the first 300 pages were read (PDF has ${numPages} pages).`
        );
      }
    } catch (pdfError) {
      loadingManager.hideToast(pdfToast);
      console.error('Chat.js: Add page button - PDF failed:', pdfError.message);
      loadingManager.showToast(pdfError.message, 'error');
    }
  }

  // Add event listeners for quick action buttons
  if (addPageButton) {
    addPageButton.addEventListener('click', async () => {
      let loadingToast = null;
      try {
        loadingToast = loadingManager.showToast('Loading tab content...', 'info');

        const response = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({ action: 'getLoadContent' }, (res) => {
            if (chrome.runtime.lastError) {
              reject(new Error(friendlyRuntimeErrorMessage(chrome.runtime.lastError.message)));
            } else {
              resolve(res);
            }
          });
        });

        if (response && response.action === 'loadContentResponse') {
          if (response.isPdf) {
            await loadPdfContent(response, loadingToast);
          } else if (response.success && response.content) {
            loadingManager.hideToast(loadingToast);
            applyLoadedPageContent(response);
          } else {
            loadingManager.hideToast(loadingToast);
            const errorMsg = response.error || 'Content not available';
            console.error('Chat.js: Add page button - Failed:', errorMsg);
            loadingManager.showToast('No content received: ' + errorMsg, 'error');
          }
        } else {
          loadingManager.hideToast(loadingToast);
          loadingManager.showToast('Unexpected response from background script', 'error');
        }
      } catch (error) {
        if (loadingToast) loadingManager.hideToast(loadingToast);
        console.error('Chat.js: Add page button - Error:', error.message);
        loadingManager.showToast(friendlyRuntimeErrorMessage(error), 'error');
      }
    });
  }

  // Analyze button - runs last used preset mode on page content
  if (analyzeButton) {
    analyzeButton.addEventListener('click', () => {
      executePagePresetMode(lastUsedPreset);
    });
  }

  if (proofreadButton) {
    proofreadButton.addEventListener('click', () => {
      executeSelectedTextMode('proofread');
    });
  }

  // ── Slash-command typeahead picker ────────────────────────────
  let slashMenuVisible = false;
  let slashMenu = null;
  let slashCandidates = [];
  let slashActiveIndex = 0;
  let cachedSkills = [];
  let cachedSlashCommands = [];
  let slashLoaded = false;

  // Analyze dropdown - shows preset menu
  let presetMenuVisible = false;
  let presetMenu = null;

  function createPresetMenu() {
    if (presetMenu) return presetMenu;

    presetMenu = document.createElement('div');
    presetMenu.id = 'preset-menu';

    Object.values(PRESET_MODES).forEach((preset) => {
      const item = document.createElement('button');
      item.className = 'preset-menu-item';
      item.dataset.mode = preset.key;
      item.textContent = preset.label;

      item.addEventListener('click', () => {
        hidePresetMenu();
        executeSelectedTextMode(preset.key);
      });

      presetMenu.appendChild(item);
    });

    document.body.appendChild(presetMenu);
    return presetMenu;
  }

  function positionMenu(menu, anchor) {
    const rect = anchor.getBoundingClientRect();
    menu.style.left = `${rect.left}px`;
    menu.style.top = `${rect.bottom + 4}px`;
  }

  function showPresetMenu() {
    const menu = createPresetMenu();
    positionMenu(menu, analyzeDropdown);
    menu.style.display = 'block';
    presetMenuVisible = true;
  }

  function hidePresetMenu() {
    if (presetMenu) {
      presetMenu.style.display = 'none';
    }
    presetMenuVisible = false;
  }

  if (analyzeDropdown) {
    analyzeDropdown.addEventListener('click', (e) => {
      e.stopPropagation();
      if (presetMenuVisible) {
        hidePresetMenu();
      } else {
        showPresetMenu();
      }
    });
  }

  // Close menu when clicking outside
  document.addEventListener('click', (e) => {
    if (presetMenuVisible && !presetMenu?.contains(e.target)) {
      hidePresetMenu();
    }
  });

  // Custom Prompts Dropdown
  let customPromptsMenuVisible = false;
  let customPromptsMenu = null;

  async function createCustomPromptsMenu() {
    if (customPromptsMenu) return customPromptsMenu;
    customPromptsMenu = document.createElement('div');
    customPromptsMenu.id = 'custom-prompts-menu';
    document.body.appendChild(customPromptsMenu);
    return customPromptsMenu;
  }

  async function populateCustomPromptsMenu() {
    const menu = await createCustomPromptsMenu();
    menu.innerHTML = '';

    const { instructions, pinnedQuickActions } = await new Promise((resolve) => {
      chrome.storage.local.get(['instructions', 'pinnedQuickActions'], resolve);
    });

    const allInstructions = instructions || [];
    const pinnedIds = new Set(pinnedQuickActions || []);

    if (allInstructions.length === 0) {
      menu.innerHTML =
        '<div class="custom-prompt-item" style="color:var(--ext-muted-foreground);font-style:italic;cursor:default;">No custom prompts</div>';
      return;
    }

    const sorted = [...allInstructions].sort((a, b) => {
      const aPinned = pinnedIds.has(a.id);
      const bPinned = pinnedIds.has(b.id);
      if (aPinned && !bPinned) return -1;
      if (!aPinned && bPinned) return 1;
      return (a.name || '').localeCompare(b.name || '');
    });

    sorted.forEach((instruction) => {
      const isPinned = pinnedIds.has(instruction.id);
      const item = document.createElement('button');
      item.className = 'custom-prompt-item' + (isPinned ? ' pinned' : '');
      const iconLetter = instruction.name ? instruction.name[0].toUpperCase() : '?';
      const icon = document.createElement('span');
      icon.className = 'custom-prompt-icon';
      icon.textContent = iconLetter;
      item.appendChild(icon);
      item.appendChild(document.createTextNode(instruction.name || 'Untitled prompt'));
      item.addEventListener('click', () => {
        hideCustomPromptsMenu();
        executeSelectedTextInstruction(instruction);
      });
      menu.appendChild(item);
    });
  }

  async function showCustomPromptsMenu() {
    await populateCustomPromptsMenu();
    positionMenu(customPromptsMenu, customPromptsDropdown);
    customPromptsMenu.style.display = 'block';
    customPromptsMenuVisible = true;
  }

  function hideCustomPromptsMenu() {
    if (customPromptsMenu) customPromptsMenu.style.display = 'none';
    customPromptsMenuVisible = false;
  }

  const customPromptsDropdown = document.getElementById('custom-prompts-dropdown');
  if (customPromptsDropdown) {
    customPromptsDropdown.addEventListener('click', (e) => {
      e.stopPropagation();
      customPromptsMenuVisible ? hideCustomPromptsMenu() : showCustomPromptsMenu();
    });
  }

  document.addEventListener('click', (e) => {
    if (
      customPromptsMenuVisible &&
      !customPromptsMenu?.contains(e.target) &&
      !customPromptsDropdown?.contains(e.target)
    ) {
      hideCustomPromptsMenu();
    }
  });

  window.addEventListener(
    'scroll',
    () => {
      if (presetMenuVisible && presetMenu && analyzeDropdown)
        positionMenu(presetMenu, analyzeDropdown);
      if (customPromptsMenuVisible && customPromptsMenu && customPromptsDropdown) {
        positionMenu(customPromptsMenu, customPromptsDropdown);
      }
    },
    true
  );
  window.addEventListener('resize', () => {
    if (presetMenuVisible && presetMenu && analyzeDropdown)
      positionMenu(presetMenu, analyzeDropdown);
    if (customPromptsMenuVisible && customPromptsMenu && customPromptsDropdown) {
      positionMenu(customPromptsMenu, customPromptsDropdown);
    }
  });

  // ── Slash-command typeahead picker functions ─────────────────

  async function refreshSlashCandidates() {
    try {
      const resp = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'getSkills' }, (response) => {
          if (chrome.runtime.lastError) resolve({ skills: [], slashCommands: [] });
          else resolve(response || { skills: [], slashCommands: [] });
        });
      });
      cachedSkills = resp.skills || [];
      cachedSlashCommands = resp.slashCommands || [];
    } catch {
      cachedSkills = [];
      cachedSlashCommands = [];
    }
  }

  function createSlashMenu() {
    if (slashMenu) return slashMenu;
    slashMenu = document.createElement('div');
    slashMenu.id = 'slash-command-menu';
    document.body.appendChild(slashMenu);
    return slashMenu;
  }

  function positionSlashMenu() {
    if (!slashMenu) return;
    const wrapper = document.getElementById('input-wrapper');
    if (!wrapper) return;
    const rect = wrapper.getBoundingClientRect();
    slashMenu.style.left = `${rect.left}px`;
    slashMenu.style.bottom = `${window.innerHeight - rect.top + 4}px`;
    slashMenu.style.top = 'auto';
  }

  function updateSlashMenu(query) {
    const menu = createSlashMenu();

    const { buildSlashCandidates: build, filterSlashCandidates: filter } = _chatSkillsModule || {};
    if (!build || !filter) return;

    const allCandidates = build(cachedSkills, cachedSlashCommands);
    const filtered = filter(query, allCandidates);

    menu.innerHTML = '';
    slashActiveIndex = 0;

    if (filtered.length === 0) {
      menu.style.display = 'none';
      slashMenuVisible = false;
      return;
    }

    filtered.forEach((candidate, idx) => {
      const item = document.createElement('button');
      item.className = 'slash-menu-item' + (idx === 0 ? ' active' : '');
      item.dataset.index = idx;

      const nameSpan = document.createElement('span');
      nameSpan.className = 'slash-menu-name';
      nameSpan.textContent = candidate.label;
      item.appendChild(nameSpan);

      if (candidate.description) {
        const descSpan = document.createElement('span');
        descSpan.className = 'slash-menu-desc';
        descSpan.textContent = candidate.description;
        item.appendChild(descSpan);
      }

      item.addEventListener('click', () => {
        acceptSlash(candidate);
      });

      menu.appendChild(item);
    });

    slashCandidates = filtered;
    positionSlashMenu();
    menu.style.display = 'block';
    slashMenuVisible = true;
  }

  function moveSlashActive(delta) {
    if (!slashMenuVisible || slashCandidates.length === 0) return;
    const items = slashMenu.querySelectorAll('.slash-menu-item');
    if (items.length === 0) return;

    items[slashActiveIndex]?.classList.remove('active');
    slashActiveIndex = (slashActiveIndex + delta + items.length) % items.length;
    items[slashActiveIndex]?.classList.add('active');
    items[slashActiveIndex]?.scrollIntoView({ block: 'nearest' });
  }

  function acceptSlash(candidate) {
    if (!candidate) return;
    const input = document.getElementById('user-input');
    if (!input) return;

    const val = input.value;
    const slashIdx = val.indexOf('/');
    if (slashIdx !== -1) {
      input.value = val.slice(0, slashIdx) + candidate.label + ' ';
    } else {
      input.value = candidate.label + ' ';
    }

    hideSlashMenu();
    input.focus();
  }

  function hideSlashMenu() {
    if (slashMenu) {
      slashMenu.style.display = 'none';
    }
    slashMenuVisible = false;
    slashActiveIndex = 0;
    slashLoaded = false;
  }

  function isSlashMenuVisible() {
    return slashMenuVisible;
  }

  if (explainButton) {
    explainButton.addEventListener('click', async () => {
      await runSelectedTextPrompt(buildExplainPrompt('selected text'), 'auto', 'run Explain');
    });
  }

  if (selectedTextRemoveButton) {
    selectedTextRemoveButton.addEventListener('click', () => {
      clearSelectedTextState();
      loadingManager.showToast(
        'Selected text detached — actions now continue the conversation',
        'info'
      );
    });
  }

  // Initialize web search grounding toggle
  initWebSearchToggle(document.getElementById('web-search-toggle'), loadingManager);

  const darkThemeToggle = document.getElementById('darkThemeToggle');
  if (darkThemeToggle) {
    setupThemeToggle(darkThemeToggle);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.pinnedQuickActions || changes.instructions)) {
      renderPinnedActions();
    }
  });

  const PENDING_PANEL_ACTION_KEY = 'pendingPanelAction';

  let selectedText = null;
  let tabId = null;
  let panelTabId = null; // Owning tab for this side panel (set from message sender)
  let currentAbortController = null;
  let lastProcessedPanelActionId = null;
  let isResponseInFlight = false;
  const inputArea = document.getElementById('input-area');
  let currentAttachmentPreviewUrl = null;
  const contextTray = document.getElementById('context-tray');
  const quickActionsRow = document.getElementById('quick-actions-row');

  // Streaming and API call state manager
  const streamState = new StreamStateManager();
  streamState.setChatAreaRef(chatArea);

  // Convenience aliases for backward compatibility
  const getCurrentRunId = () => streamState.getRunId();
  const setCurrentRunId = (id) => streamState.setRunId(id);
  const getCurrentSourceTabId = () => streamState.getSourceTabId();
  const setCurrentSourceTabId = (id) => streamState.setSourceTabId(id);
  const getCurrentMediaData = () => streamState.getMediaData();
  const getConversationHistory = () => streamState.getConversationHistory();
  const setConversationHistory = (history) => streamState.setConversationHistory(history);

  // A run is only genuinely active while its streaming bubble is still live.
  // The streaming element is created right before startRun() and cleared on
  // every terminal event, so a run id with no streaming element means the run
  // is stranded (its terminal event was never delivered) and must not block
  // future runs.
  function hasLiveStreamingRun() {
    return (
      Boolean(streamState.getRunId()) && Boolean(streamState.getCurrentStreamingContentElement())
    );
  }

  function isResponseBusy() {
    return isResponseInFlight || hasLiveStreamingRun();
  }

  function beginResponseRun() {
    if (isResponseBusy()) {
      console.warn('Chat: run start rejected - response already in flight', {
        currentRunId: streamState.getRunId(),
        sourceTabId: streamState.getSourceTabId(),
      });
      loadingManager.showToast('A response is already in progress', 'warning');
      return false;
    }

    // Recover from a stranded run whose terminal event never arrived so it
    // doesn't permanently block new runs. Also clear the streaming elements
    // so any permanent "Loading…" or "Using tool:…" bubble is removed.
    if (streamState.getRunId()) {
      console.warn('Chat: clearing stranded run state before starting a new run', {
        strandedRunId: streamState.getRunId(),
        sourceTabId: streamState.getSourceTabId(),
      });
      streamState.clearStreamingElements();
      streamState.clearStreamedText();
      streamState.setActiveToolCall(null);
      streamState.setRunId(null);
      streamState.setSourceTabId(null);
    }

    isResponseInFlight = true;
    return true;
  }

  function endResponseRun() {
    isResponseInFlight = false;
  }

  // Terminal run UI reset: re-enable input, restore the Clear label, and
  // apply the terminal run state to the input area.
  function resetRunUi(runState) {
    userInput.disabled = false;
    sendButton.disabled = false;
    clearButton.textContent = 'Clear';
    setRunState(inputArea, runState);
  }

  // Begin-run UI: disable input and switch the action button to Stop.
  function beginRunUi() {
    userInput.disabled = true;
    sendButton.disabled = true;
    clearButton.textContent = 'Stop';
    setRunState(inputArea, RUN_STATES.STREAMING);
  }

  // Shared failure cleanup for both run entry points.
  function handleRunFailure(error, source) {
    console.error(`${source} Error:`, error);
    chatUI.addMessage('System', 'Error: ' + error.message);
    resetRunUi(RUN_STATES.ERROR);
    userInput.focus();
    clearCurrentMediaData();
    streamState.clearStreamingElements();
    streamState.clearStreamedText();
    streamState.appendStreamedText('');
    streamState.setActiveToolCall(null);
    streamState.setRunId(null);
    streamState.setSourceTabId(null);
  }

  function syncChatAreaHeight() {
    if (!inputArea) return;
    document.documentElement.style.setProperty(
      '--chat-input-area-height',
      `${inputArea.offsetHeight}px`
    );
  }

  function revokeAttachmentPreviewUrl() {
    if (currentAttachmentPreviewUrl && currentAttachmentPreviewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(currentAttachmentPreviewUrl);
    }
    currentAttachmentPreviewUrl = null;
  }

  function clearCurrentMediaData() {
    streamState.clearMediaData();
    chatUI.clearAttachmentPreview();
    revokeAttachmentPreviewUrl();
    syncChatAreaHeight();
  }

  function handleAttachmentRemove() {
    clearCurrentMediaData();
    loadingManager.showToast('Pasted image attachment removed', 'info');
  }

  function setCurrentMediaData(data) {
    revokeAttachmentPreviewUrl();
    streamState.setMediaData(data);
    currentAttachmentPreviewUrl = data?.previewUrl || null;

    if (data && data.source === 'clipboard') {
      chatUI.setAttachmentPreview(data, handleAttachmentRemove);
    } else {
      chatUI.clearAttachmentPreview();
    }

    syncChatAreaHeight();
  }

  async function handleUserInputPaste(event) {
    const clipboardData = event.clipboardData;
    if (!clipboardData || userInput.disabled) return;

    const items = Array.from(clipboardData.items || []);
    const imageItem = items.find((item) => item.kind === 'file' && item.type.startsWith('image/'));
    const imageFile =
      imageItem?.getAsFile?.() ||
      Array.from(clipboardData.files || []).find((file) => file.type.startsWith('image/'));

    if (!imageFile) return;

    event.preventDefault();

    try {
      const mediaModule = await getChatMedia();
      const fileData = await mediaModule.readBlobAsBase64(imageFile, 'pasted-image');
      const fileName =
        imageFile.name && imageFile.name.trim() ? imageFile.name.trim() : 'Pasted image';
      const previewUrl = URL.createObjectURL(imageFile);

      setCurrentMediaData({
        type: MediaType.IMAGE,
        mimeType: fileData.mimeType || imageFile.type || 'image/png',
        base64: fileData.base64,
        name: fileName,
        previewUrl,
        source: 'clipboard',
      });

      loadingManager.showToast('Pasted image attached', 'success');
    } catch (error) {
      console.error('Chat: Failed to process pasted image:', error);
      clearCurrentMediaData();
      chatUI.addMessage('System', `❌ Failed to attach pasted image: ${error.message}`);
    }
  }

  syncChatAreaHeight();
  window.addEventListener('resize', syncChatAreaHeight);

  /**
   * Stops the current API request by aborting the orchestrator run.
   */
  async function stopApiRequest() {
    setRunState(inputArea, RUN_STATES.STOPPING);
    if (streamState.getRunId()) {
      await abortRun(streamState.getRunId());
    }
  }

  function getRunSourceTabId() {
    return tabId || panelTabId || null;
  }

  // Removes the loaded page context: clears state, hides the tray item, and
  // removes the expandable content message from the chat DOM.
  function detachPageContext(silent = false) {
    lastLoadedPageContext = null;
    const container = document.querySelector('.loaded-content-container');
    if (container) container.remove();
    composer.setPageContext(null);
    syncChatAreaHeight();
    if (!silent) loadingManager.showToast('Page content detached', 'info');
  }

  // Composer recovery: Continue always builds on the previous response;
  // other quick actions reuse the sticky-selection prompt path.
  async function sendComposerPrompt(instruction, actionLabel) {
    if (actionLabel === 'continue' && hasConversation()) {
      await makeApiCall({ instruction, context: { type: 'previous_response' } }, 'auto');
      return;
    }
    await runSelectedTextPrompt(instruction, 'auto', actionLabel);
  }

  // Composer-led UI: context tray, quick actions, inline recovery. All new
  // composer logic lives in ChatComposer.js; chat.js only supplies handlers.
  const composer = chatComposer.initComposer({
    container: inputArea,
    tray: contextTray,
    row: quickActionsRow,
    chatArea: document.getElementById('chat-area'),
    inputField: userInput,
    handlers: {
      onStop: () => stopApiRequest(),
      onAnalyze: () => executePagePresetMode(lastUsedPreset),
      onMode: (modeKey) => executeSelectedTextMode(modeKey),
      onPrompt: (instruction, actionLabel) => sendComposerPrompt(instruction, actionLabel),
      onEdit: (instruction) => {
        userInput.value = instruction || '';
        userInput.dispatchEvent(new Event('input'));
        userInput.focus();
      },
      onDetachPage: () => detachPageContext(),
    },
  });

  /**
   * Retrieves the API configuration from Chrome storage.
   * @returns {Promise<Object>} The selected profile configuration.
   * @throws {Error} If configuration is incomplete or cannot be read.
   */
  /**
   * Attaches click event listeners to copy icons for copying message content.
   * @param {string} rawMessage - The raw text message to copy.
   * @param {HTMLElement} contentElement - The element containing the formatted content.
   * @param {HTMLElement} copyIconElement - The copy icon element for plain text.
   * @param {HTMLElement} copyFormattedIconElement - The copy icon element for formatted text.
   */

  function applySetSelectedTextAction(request) {
    if (request.actionId && request.actionId === lastProcessedPanelActionId) {
      return false;
    }

    if (request.actionId) {
      lastProcessedPanelActionId = request.actionId;
    }

    selectedText = request.selectedText || '';
    tabId = request.tabId;
    refreshSelectedTextActionState();

    // Deep-link instruction: run it immediately against the attached context.
    if (request.textPrompt && request.textPrompt.trim()) {
      const instruction = request.textPrompt.trim();
      const text = getSelectedText();
      if (text) {
        void runSelectedTextPrompt(instruction, 'auto', 'deep link');
      } else {
        void makeApiCall({ instruction, context: { type: 'previous_response' } }, 'auto');
      }
    }

    // Handle media data from context menu
    if (request.mediaData) {
      setCurrentMediaData(request.mediaData);

      // Show chat area with media preview
      chatMainArea.classList.remove('hidden');
      oneoffInstructionArea.classList.add('hidden');

      if (streamState.getMediaData().error) {
        chatUI.addMessage(
          'System',
          `❌ Error loading ${streamState.getMediaData().type}: ${streamState.getMediaData().error}`
        );
      } else if (streamState.getMediaData().base64) {
        chatUI.addMediaPreview(streamState.getMediaData());
      }
    } else if (request.fromStartChat) {
      chatMainArea.classList.remove('hidden');
      oneoffInstructionArea.classList.add('hidden');
      streamState.clearHistory();
      clearCurrentMediaData();
    } else {
      selectedTextDiv.textContent = selectedText;
      chatMainArea.classList.add('hidden');
      oneoffInstructionArea.classList.remove('hidden');
    }

    return true;
  }

  function applySetMediaForAnalysisAction(request) {
    if (request.actionId && request.actionId === lastProcessedPanelActionId) {
      console.log('Chat: Ignoring duplicate setMediaForAnalysis actionId:', request.actionId);
      return false;
    }

    if (request.actionId) {
      lastProcessedPanelActionId = request.actionId;
    }

    const mediaData = request.mediaData || {};
    tabId = request.tabId;

    chatMainArea.classList.remove('hidden');
    oneoffInstructionArea.classList.add('hidden');

    if (mediaData.loading) {
      chatUI.addMessage('System', `Loading ${mediaData.type} for analysis...`);
    } else if (mediaData.error) {
      chatUI.addMessage('System', `Error loading ${mediaData.type}: ${mediaData.error}`);
    } else if (mediaData.base64 || mediaData.textPrompt) {
      if (mediaData.base64) {
        setCurrentMediaData(mediaData);
        chatUI.addMediaPreview(streamState.getMediaData());
      }

      let analysisPrompt;
      if (mediaData.actionType === 'custom' && mediaData.instructionId) {
        chrome.storage.local.get(['instructions'], (result) => {
          const instructions = result.instructions || [];
          const instruction = instructions.find((i) => i.id === mediaData.instructionId);
          let instructionToolChoice = 'auto';
          if (instruction) {
            analysisPrompt = mediaData.textPrompt || instruction.content;
            instructionToolChoice = normalizeToolChoice(instruction.tool_choice);
            chatUI.addMessage('System', `Using custom instruction: "${instruction.name}"`);
          } else {
            analysisPrompt =
              mediaData.textPrompt || getMediaAnalysisPrompt('default', streamState.getMediaData());
          }

          if (streamState.getMediaData()) {
            makeApiCallWithMedia(
              {
                instruction: analysisPrompt,
                context: {
                  type: 'media',
                },
              },
              streamState.getMediaData(),
              instructionToolChoice
            );
          } else {
            makeApiCall(
              {
                instruction: analysisPrompt,
                context: {
                  type: 'media',
                },
              },
              instructionToolChoice
            );
          }
        });
        return true;
      } else if (mediaData.actionType === 'summarize') {
        analysisPrompt =
          mediaData.textPrompt || getMediaAnalysisPrompt('summarize', streamState.getMediaData());
        chatUI.addMessage('System', `Summarizing...`);
      } else if (mediaData.actionType === 'explain') {
        analysisPrompt =
          mediaData.textPrompt || getMediaAnalysisPrompt('explain', streamState.getMediaData());
        chatUI.addMessage('System', `Explaining...`);
      } else {
        analysisPrompt =
          mediaData.textPrompt || getMediaAnalysisPrompt('default', streamState.getMediaData());
        chatUI.addMessage('System', `Analyzing...`);
      }

      if (streamState.getMediaData()) {
        makeApiCallWithMedia(
          {
            instruction: analysisPrompt,
            context: {
              type: 'media',
            },
          },
          streamState.getMediaData()
        );
      } else {
        makeApiCall({
          instruction: analysisPrompt,
          context: {
            type: 'media',
          },
        });
      }
    }

    return true;
  }

  function consumePendingPanelAction(pendingAction) {
    const pendingPanelActions = ['setSelectedText', 'setMediaForAnalysis'];
    if (!pendingAction || !pendingPanelActions.includes(pendingAction.action)) {
      return;
    }
    // Drop stale queued actions older than 30 seconds
    if (pendingAction.queuedAt && Date.now() - pendingAction.queuedAt > 30000) {
      console.warn('Chat: Dropping stale queued action:', pendingAction.action);
      if (chrome.storage?.session) {
        chrome.storage.session.remove([PENDING_PANEL_ACTION_KEY]);
      }
      return;
    }
    // Filter: only process pending actions for our panel
    if (pendingAction.tabId && panelTabId && pendingAction.tabId !== panelTabId) {
      console.log('Chat: Ignoring pending action for other panel');
      if (chrome.storage?.session) {
        chrome.storage.session.remove([PENDING_PANEL_ACTION_KEY]);
      }
      return;
    }
    let consumed = false;
    if (pendingAction.action === 'setSelectedText') {
      consumed = applySetSelectedTextAction(pendingAction);
    } else if (pendingAction.action === 'setMediaForAnalysis') {
      consumed = applySetMediaForAnalysisAction(pendingAction);
    }

    if (chrome.storage?.session) {
      chrome.storage.session.remove([PENDING_PANEL_ACTION_KEY]);
    }
    console.log('Chat: Consumed pending panel action:', pendingAction.action, { consumed });
  }

  function consumePendingPanelActionOnLoad() {
    if (!chrome.storage?.session) return;
    chrome.storage.session.get([PENDING_PANEL_ACTION_KEY], (result) => {
      consumePendingPanelAction(result?.[PENDING_PANEL_ACTION_KEY]);
    });
  }
  // Consume queued panel actions whenever written to session storage
  if (chrome.storage?.session) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'session') return;
      const pending = changes[PENDING_PANEL_ACTION_KEY];
      if (!pending?.newValue) return;
      consumePendingPanelAction(pending.newValue);
    });
  }
  function isSkillLoaderTool(toolName) {
    return toolName === 'load_skill' || toolName === 'skill_view';
  }

  function tryParseToolPayload(value) {
    if (value == null || value === '') return {};
    if (typeof value === 'object') return value;

    const normalized = String(value).trim();
    if (!normalized) return {};

    try {
      return JSON.parse(normalized);
    } catch (error) {
      for (let i = normalized.length - 1; i >= 0; i--) {
        const char = normalized[i];
        if (char !== '{' && char !== '[') continue;

        try {
          return JSON.parse(normalized.slice(i));
        } catch (innerError) {
          // Keep scanning for a recoverable trailing JSON payload.
        }
      }
      throw error;
    }
  }

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Capture panel's owning tab on first message (establishes identity)
    if (sender.tab?.id && panelTabId === null) {
      panelTabId = sender.tab.id;
      console.log('Chat: Panel registered with tabId:', panelTabId);
    }

    // Helper: check if this message belongs to our panel
    const isPanelAction =
      request.tabId != null && panelTabId != null && request.tabId !== panelTabId;

    if (request.action === 'setSelectedText') {
      // Filter out messages for other panels
      if (isPanelAction) {
        console.log(
          'Chat: Ignoring setSelectedText for other panel',
          request.tabId,
          'vs',
          panelTabId
        );
        if (sendResponse) sendResponse({ success: true, ignored: true });
        return true;
      }
      const consumed = applySetSelectedTextAction(request);
      if (sendResponse) sendResponse({ success: true, ignored: !consumed });
      return true;
    } else if (request.action === 'setMediaForAnalysis') {
      // Filter out messages for other panels
      if (isPanelAction) {
        console.log(
          'Chat: Ignoring setMediaForAnalysis for other panel',
          request.tabId,
          'vs',
          panelTabId
        );
        if (sendResponse) sendResponse({ success: true, ignored: true });
        return true;
      }

      const consumed = applySetMediaForAnalysisAction(request);
      if (sendResponse) sendResponse({ success: true, ignored: !consumed });
      return true;
    } else if (request.action === 'orchestratorEvent') {
      // NEW: Handle events from orchestrator
      const { runId, sourceTabId, event } = request;

      // Filter events by run ID first; side panels may not receive a tab identity.
      const currentRunId = streamState.getRunId();
      const currentSourceTabId = streamState.getSourceTabId();
      const sourceTabsMatch =
        sourceTabId == null || currentSourceTabId == null || sourceTabId === currentSourceTabId;
      const isOwnedEvent = currentRunId && runId === currentRunId && sourceTabsMatch;

      if (!isOwnedEvent) {
        // Terminal-event safety net: when the event is terminal and there is a
        // live streaming element but isOwnedEvent failed (runId mismatch, or
        // sourceTabId hasn't registered yet), finalize the bubble and unlock
        // instead of silently dropping. Prevents permanently "Loading…" bubbles
        // and empty sidebar.
        const terminalTypes = ['complete', 'error', 'aborted'];
        if (terminalTypes.includes(event.type) && streamState.getCurrentStreamingContentElement()) {
          console.log('Chat: Finalizing stranded bubble for terminal event', {
            runId,
            eventType: event.type,
            currentRunId,
            sourceTabId,
            currentSourceTabId,
          });
          if (event.type === 'complete') {
            const body = buildFinalResponseBody(
              event.content,
              streamState.getStreamedText(),
              event.grounding?.sources || [],
              event.completion
            );
            streamState.getCurrentStreamingContentElement().innerHTML = renderMarkdownContent(body);
            if (body.trim()) streamState.addMessageToHistory({ role: 'assistant', content: body });
          } else if (event.type === 'error') {
            streamState.getCurrentStreamingContentElement().innerHTML = renderMarkdownContent(
              '❌ Error: ' + (event.error || 'unknown error')
            );
          } else if (event.type === 'aborted') {
            streamState.getCurrentStreamingContentElement().innerHTML =
              renderMarkdownContent('Response stopped');
          }
          resetRunUi(RUN_STATES.IDLE);
          streamState.clearStreamingElements();
          streamState.clearStreamedText();
          streamState.setActiveToolCall(null);
          streamState.setRunId(null);
          streamState.setSourceTabId(null);
          endResponseRun();
          if (sendResponse) sendResponse({ success: true });
          return true;
        }
        console.log('Chat: Ignoring orchestratorEvent for other run/tab', {
          runId,
          sourceTabId,
          panelTabId,
          currentRunId,
          currentSourceTabId,
        });
        if (sendResponse) sendResponse({ success: true, ignored: true });
        return true;
      }

      switch (event.type) {
        case 'reasoning':
          if (streamState.getCurrentStreamingMessageDiv() && event.data) {
            if (!streamState.getReasoningContentElement()) {
              const reasoningEl = chatUI.ensureReasoningPanel(
                streamState.getCurrentStreamingMessageDiv()
              );
              streamState.setReasoningContentElement(reasoningEl);
            }
            streamState.markReasoningStart();
            streamState.queueRenderReasoning(event.data);
          }
          break;

        case 'content':
          if (streamState.getCurrentStreamingContentElement() && event.data) {
            // First answer token after reasoning — collapse the thinking panel.
            if (streamState.getReasoningContentElement()) {
              chatUI.finalizeReasoningPanel(
                streamState.getCurrentStreamingMessageDiv(),
                streamState.getReasoningElapsedMs()
              );
            }
            streamState.queueRenderChunk(event.data);
          }
          break;

        case 'tool_start':
          // Collapse any open thinking panel before the tool trace replaces the bubble.
          if (streamState.getReasoningContentElement()) {
            chatUI.finalizeReasoningPanel(
              streamState.getCurrentStreamingMessageDiv(),
              streamState.getReasoningElapsedMs()
            );
          }
          // Clear stale turn-1 streaming state so the continuation turn renders fresh.
          // Without this, accumulatedStreamedText from the first turn survives into
          // the answer and can appear as if the rewrite "never occurred".
          streamState.startNewTurn();
          streamState.setActiveToolCall(event.toolCall);
          if (streamState.getCurrentStreamingContentElement()) {
            if (event.capability === 'skill' || isSkillLoaderTool(event.toolCall.function.name)) {
              streamState.getCurrentStreamingContentElement().innerHTML = renderMarkdownContent(
                `Loading skill: **${event.toolCall.function.name}**`
              );
            } else {
              streamState.getCurrentStreamingContentElement().innerHTML = renderMarkdownContent(
                `⚙️ Using tool: **${event.toolCall.function.name}**`
              );
            }
          }
          break;

        case 'tool_ready':
          chatUI.addMessage('System', `⚙️ Executing tool: **${event.toolCall.function.name}**...`);
          break;

        case 'tool_complete':
          // Distinguish tool vs skill in the trace
          if (isSkillLoaderTool(event.toolCall.function.name)) {
            try {
              clearCurrentMediaData();
              const args = tryParseToolPayload(event.toolCall.function.arguments);
              const resultObj = tryParseToolPayload(event.result);
              const skillResult = resultObj?.result || resultObj;
              if (skillResult && skillResult.success) {
                chatUI.addMessage('System', `Loaded skill: **${args.name || 'unknown'}**`);
                const skillContent = JSON.stringify(skillResult);
                const contentPreview =
                  skillContent.substring(0, 200) + (skillContent.length > 200 ? '...' : '');
                chatUI.addMessage(
                  'System',
                  `Skill instructions preview:\n\`\`\`\n${contentPreview}\n\`\`\``
                );
              } else {
                chatUI.addMessage('System', `⚠️ Skill **${args.name || 'unknown'}** not found.`);
              }
            } catch (e) {
              console.warn(
                `Could not parse ${event.toolCall.function.name} arguments for traceability`
              );
            }
          } else {
            const resultObj = tryParseToolPayload(event.result);
            const outcome = classifyToolExecutionResult(resultObj);
            if (outcome.payload?.skill) {
              chatUI.addMessage(
                'System',
                `📚 Loaded skill: **${outcome.payload.skill.name || event.toolCall.function.name}**`
              );
            } else if (outcome.status !== 'success') {
              chatUI.addMessage(
                'System',
                `⚠️ Tool ${event.toolCall.function.name}: ${outcome.message || outcome.error || 'error'}`
              );
            } else {
              chatUI.addMessage('System', `✅ Tool ${event.toolCall.function.name} executed.`);
            }
          }
          break;
        case 'tool_error':
          chatUI.addMessage(
            'System',
            `❌ Error executing tool ${event.toolCall.function.name}: ${event.error}`
          );

          streamState.setActiveToolCall(null);
          break;

        case 'complete': {
          // Collapse the thinking panel if it never got collapsed (e.g. reasoning-only turn).
          if (streamState.getReasoningContentElement()) {
            chatUI.finalizeReasoningPanel(
              streamState.getCurrentStreamingMessageDiv(),
              streamState.getReasoningElapsedMs()
            );
          }

          const body = buildFinalResponseBody(
            event.content,
            streamState.getStreamedText(),
            event.grounding?.sources || [],
            event.completion
          );

          if (streamState.getCurrentStreamingContentElement()) {
            streamState.getCurrentStreamingContentElement().innerHTML = renderMarkdownContent(body);
            postProcessRenderedContent(streamState.getCurrentStreamingContentElement());

            const msgDiv = streamState.getCurrentStreamingMessageDiv();
            const uid = streamState.getCurrentStreamingUniqueId();
            if (msgDiv && uid) {
              const rawIcon = document.getElementById(`copy-icon-${uid}`);
              const formattedIcon = document.getElementById(`copy-formatted-icon-${uid}`);
              if (rawIcon && formattedIcon) {
                attachCopyListeners(
                  body,
                  streamState.getCurrentStreamingContentElement(),
                  rawIcon,
                  formattedIcon
                );
              }
            }
          } else {
            chatUI.addMessage('LLM', body);
          }

          if (body.trim()) {
            streamState.addMessageToHistory({
              role: 'assistant',
              content: body,
            });
          }
          resetRunUi(RUN_STATES.COMPLETE);

          // Reset run state so the next message isn't rejected as "in progress".
          // Without clearing the run id, isResponseBusy() stays true forever.
          streamState.clearStreamingElements();
          streamState.clearStreamedText();
          streamState.setActiveToolCall(null);
          streamState.setRunId(null);
          streamState.setSourceTabId(null);

          // A conversation now exists, so sidebar actions can run as follow-ups.
          refreshSelectedTextActionState();
          break;
        }
        case 'aborted': {
          chatUI.addMessage('System', 'Response stopped');
          resetRunUi(RUN_STATES.STOPPED);

          // Reset streaming variables
          streamState.clearStreamingElements();
          streamState.clearStreamedText();
          streamState.setActiveToolCall(null);
          streamState.setRunId(null);
          streamState.setSourceTabId(null);
          break;
        }
        case 'error': {
          chatUI.addMessage('System', `❌ Error: ${event.error}`);
          resetRunUi(RUN_STATES.ERROR);
          userInput.focus();

          // Reset streaming variables
          streamState.clearStreamingElements();
          streamState.clearStreamedText();
          streamState.setActiveToolCall(null);
          streamState.setRunId(null);
          streamState.setSourceTabId(null);
          break;
        }
      }

      if (sendResponse) sendResponse({ success: true });
      return true;
    }
  });

  sendButton.addEventListener('click', sendMessage);
  const clearButton = document.getElementById('clear-button');

  clearButton.addEventListener('click', () => {
    if (clearButton.textContent === 'Stop') {
      stopApiRequest();
    } else {
      chatUI.clearChat();
      streamState.clearHistory();
      clearCurrentMediaData();
      clearSelectedTextState();
      // Keep the page tray consistent with the cleared chat DOM.
      if (lastLoadedPageContext) detachPageContext(true);
    }
  });
  userInput.addEventListener('keydown', (event) => {
    if (isSlashMenuVisible()) {
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        moveSlashActive(1);
        return;
      }
      if (event.key === 'ArrowUp') {
        event.preventDefault();
        moveSlashActive(-1);
        return;
      }
      if (event.key === 'Enter' || event.key === 'Tab') {
        event.preventDefault();
        acceptSlash(slashCandidates[slashActiveIndex]);
        return;
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        hideSlashMenu();
        return;
      }
    }
    if (event.key === 'Enter' && !event.shiftKey && !userInput.disabled) {
      event.preventDefault();
      sendMessage();
    }
  });

  userInput.addEventListener('input', async () => {
    const val = userInput.value;
    const match = val.match(/^\/(\S*)$/);
    if (match) {
      if (!_chatSkillsModule) {
        await getChatSkills();
      }
      if (!slashLoaded) {
        await refreshSlashCandidates();
        slashLoaded = true;
      }
      updateSlashMenu(match[1]);
    } else {
      hideSlashMenu();
    }
  });

  document.addEventListener('click', (e) => {
    if (slashMenuVisible && slashMenu && !slashMenu.contains(e.target) && e.target !== userInput) {
      hideSlashMenu();
    }
  });
  userInput.addEventListener('paste', handleUserInputPaste);

  consumePendingPanelActionOnLoad();

  // ── Drag & Drop Support ────────────────────────────────────────

  const dropOverlay = document.getElementById('drop-overlay');

  function showDropOverlay() {
    if (dropOverlay) dropOverlay.classList.remove('hidden');
  }
  function hideDropOverlay() {
    if (dropOverlay) dropOverlay.classList.add('hidden');
  }

  document.addEventListener('dragenter', (e) => {
    e.preventDefault();
    showDropOverlay();
  });

  document.addEventListener('dragover', (e) => {
    e.preventDefault();
  });

  document.addEventListener('dragleave', (e) => {
    // Only hide if we're leaving the document entirely
    if (!e.relatedTarget || e.relatedTarget === document.documentElement) {
      hideDropOverlay();
    }
  });

  document.addEventListener('drop', async (e) => {
    e.preventDefault();
    hideDropOverlay();

    const files = Array.from(e.dataTransfer.files);
    if (files.length === 0) return;

    chatUI.addMessage('System', `Processing ${files.length} dropped file(s)...`);

    for (const file of files) {
      try {
        const mediaModule = await getChatMedia();
        const validation = mediaModule.validateDroppedFile(file);
        if (!validation.valid) {
          chatUI.addMessage('System', `❌ ${validation.error}`);
          continue;
        }

        const fileData = await mediaModule.readFileAsBase64(file);
        const mediaType = file.type.startsWith('video/')
          ? MediaType.VIDEO
          : file.type.startsWith('audio/')
            ? MediaType.AUDIO
            : MediaType.IMAGE;

        const mediaData = {
          type: mediaType,
          mimeType: fileData.mimeType,
          base64: fileData.base64,
          textPrompt: `Analyze this ${mediaType}: ${fileData.name}`,
        };

        chatUI.addMediaPreview(mediaData);
        setCurrentMediaData(mediaData);

        // Auto-analyze with prompt
        const userPrompt = `Analyze this ${mediaModule.getMediaDisplayName(mediaType)}: ${fileData.name}`;
        makeApiCallWithMedia(
          {
            instruction: userPrompt,
            context: {
              type: 'media',
            },
          },
          mediaData
        );
      } catch (err) {
        console.error('Drop handler error:', err);
        chatUI.addMessage('System', `❌ Error processing ${file.name}: ${err.message}`);
      }
    }
  });

  /**
   * Makes an API call with media content (images, video, audio).
   * @param {string|Object} promptRequest - The user's prompt request.
   * @param {Object} mediaData - The media data object containing base64, mimeType, etc.
   * @param {string} [tool_choice='auto'] - The tool choice strategy ('none', 'auto', or specific tool name).
   * @param {string|null} [requestedSkill=null] - Name of skill to preload via orchestrator.
   * @returns {Promise<void>}
   */
  async function makeApiCallWithMedia(
    promptRequest,
    mediaData,
    tool_choice = 'auto',
    requestedSkill = null
  ) {
    if (!beginResponseRun()) return;

    try {
      clearCurrentMediaData();
      const config = await getApiConfig();
      const userMessage = composeUserPrompt(promptRequest);

      const effectiveToolChoice =
        tool_choice === undefined || tool_choice === null || tool_choice === ''
          ? 'auto'
          : tool_choice;

      // Add user message to history if provided
      if (userMessage) {
        chatUI.addMessage('User', formatUserMessageForDisplay(userMessage));

        // Create message content with media
        const messageContent = [{ type: 'text', text: userMessage }];

        // Add media content for vision models
        if (mediaData.type === 'image') {
          messageContent.push({
            type: 'image_url',
            image_url: { url: `data:${mediaData.mimeType};base64,${mediaData.base64}` },
          });
        }

        streamState.addMessageToHistory({
          role: 'user',
          content: messageContent,
        });
      }

      // Create UI elements for streaming
      const { messageDiv, contentElement, uniqueIdString } = chatUI.addMessage('LLM', '');
      streamState.initStreamingElements(messageDiv, contentElement, uniqueIdString);
      beginRunUi();

      // Prepare run configuration with media
      const webSearchEnabled = await isWebSearchEnabled();
      const runConfig = {
        llmEndpoint: config.llmEndpoint,
        apiKey: config.apiKey,
        modelName: config.modelName,
        systemPrompt: config.systemPrompt,
        tool_choice: effectiveToolChoice,
        tools: await getTools(),
        webSearch: webSearchEnabled,
        mediaData: mediaData,
        requestedSkill,
        sourceTabId: getRunSourceTabId(),
      };

      // Start orchestrator run using ChatAPI module
      streamState.setRunId(await startRun(runConfig));
      streamState.setSourceTabId(runConfig.sourceTabId);

      // Execute the run using ChatAPI module
      await executeRun(streamState.getRunId(), streamState.getConversationHistory());
    } catch (error) {
      handleRunFailure(error, 'makeApiCallWithMedia');
    } finally {
      endResponseRun();
    }
  }

  async function sendMessage() {
    streamState.setActiveToolCall(null); // Reset active tool call
    const message = userInput.value;
    const mediaData = streamState.getMediaData();
    const hasText = message.trim().length > 0;
    const hasMedia = Boolean(mediaData?.base64);

    if ((hasText || hasMedia) && !userInput.disabled) {
      let requestedSkill = null;
      let effectiveMessage = hasText ? message : `Analyze this ${mediaData?.type || 'image'}`;

      if (hasText) {
        // Fetch available skills
        const skillsResp = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ action: 'getSkills' }, (response) => {
            if (chrome.runtime.lastError) resolve({ skills: [] });
            else resolve(response || { skills: [] });
          });
        });
        const availableSkills = skillsResp && skillsResp.skills ? skillsResp.skills : [];
        const skillsModule = await getChatSkills();

        // Check for slash commands
        const cmd = skillsModule.parseCommand(message, availableSkills);

        if (cmd.type === 'skills') {
          chatUI.addMessage('User', formatUserMessageForDisplay(message));
          const slashCommands = skillsResp.slashCommands || [];
          const skillsMessage = skillsModule.formatSkillsList(availableSkills, slashCommands);
          chatUI.addMessage('System', skillsMessage);
          userInput.value = '';
          return;
        }

        if (cmd.type === 'skill') {
          requestedSkill = cmd.skillName;
          effectiveMessage = cmd.body || message;
          chatUI.addMessage('System', `Loading skill: **${requestedSkill}**`);
        } else {
          // Fall back to natural-language intent detection
          const detectedSkill = skillsModule.detectSkillIntent(message, availableSkills);
          if (detectedSkill) {
            requestedSkill = detectedSkill.skillName;
            effectiveMessage = detectedSkill.body || message;
            chatUI.addMessage(
              'System',
              `Skill detected: **${requestedSkill}**. Loading skill instructions...`
            );
          }
        }
      }

      if (hasMedia) {
        makeApiCallWithMedia(
          {
            instruction: effectiveMessage,
            context: {
              type: 'media',
            },
          },
          mediaData,
          'auto',
          requestedSkill
        );
      } else {
        makeApiCall({ instruction: effectiveMessage }, 'auto', requestedSkill);
      }
      userInput.value = '';
    }
  }

  /**
   * Makes an API call to the LLM endpoint using the orchestrator.
   * @param {string|Object} promptRequest - The user's prompt request.
   * @param {string} [tool_choice='auto'] - The tool choice strategy ('none', 'auto', or specific tool name).
   * @param {string|null} [requestedSkill=null] - Name of skill to preload via orchestrator.
   * @returns {Promise<void>}
   */
  async function makeApiCall(promptRequest = null, tool_choice = 'auto', requestedSkill = null) {
    if (!beginResponseRun()) return;

    try {
      const config = await getApiConfig();
      const userMessage = composeUserPrompt(promptRequest);

      // Adaptive model routing: check if media context needs a vision-capable model
      const mediaData = streamState.getMediaData();
      let effectiveConfig = config;
      if (mediaData && (mediaData.type === 'image' || mediaData.type === 'video')) {
        try {
          const { profiles } = await new Promise((resolve) => {
            chrome.storage.local.get(['profiles', 'lastSelectedProfileId'], resolve);
          });
          const routingResult = await selectOptimalProfile(
            profiles || [],
            config.id || 'default',
            mediaData
          );
          if (routingResult.rerouted && routingResult.config) {
            effectiveConfig = routingResult.config;
            console.log(
              `[Chat] Rerouted to vision-capable model: ${routingResult.config.modelName}`
            );
            chatUI.addMessage(
              'System',
              `Auto-switched to **${routingResult.config.modelName}** for image analysis.`
            );
          }
        } catch (e) {
          // routing failure is non-fatal — fall back to current config
        }
      }

      const effectiveToolChoice =
        tool_choice === undefined || tool_choice === null || tool_choice === ''
          ? 'auto'
          : tool_choice;

      // Add user message to history if provided
      if (userMessage) {
        chatUI.addMessage('User', formatUserMessageForDisplay(userMessage));

        if (mediaData && mediaData.type === 'image') {
          const messageContent = [
            { type: 'text', text: userMessage },
            {
              type: 'image_url',
              image_url: {
                url: `data:${mediaData.mimeType};base64,${mediaData.base64}`,
              },
            },
          ];
          streamState.addMessageToHistory({ role: 'user', content: messageContent });
        } else {
          streamState.addMessageToHistory({ role: 'user', content: userMessage });
        }

        clearCurrentMediaData(); // Clear after use
      }

      // Prepare run configuration
      const webSearchEnabled = await isWebSearchEnabled();
      const runConfig = {
        llmEndpoint: effectiveConfig.llmEndpoint,
        apiKey: effectiveConfig.apiKey,
        modelName: effectiveConfig.modelName,
        systemPrompt: effectiveConfig.systemPrompt,
        tool_choice: effectiveToolChoice,
        tools: await getTools(),
        webSearch: webSearchEnabled,
        requestedSkill,
        sourceTabId: getRunSourceTabId(),
      };

      // Create UI elements for streaming
      const { messageDiv, contentElement, uniqueIdString } = chatUI.addMessage('LLM', '');
      streamState.initStreamingElements(messageDiv, contentElement, uniqueIdString);
      beginRunUi();

      // Start orchestrator run using ChatAPI module
      streamState.setRunId(await startRun(runConfig));
      streamState.setSourceTabId(runConfig.sourceTabId);

      // Execute the run using ChatAPI module
      await executeRun(streamState.getRunId(), streamState.getConversationHistory());
    } catch (error) {
      handleRunFailure(error, 'makeApiCall');
    } finally {
      endResponseRun();
    }
  }

  submitBtn.addEventListener('click', async () => {
    streamState.setActiveToolCall(null);
    const instruction = instructionInput.value;
    if (!instruction.trim()) {
      loadingManager.showToast('Please enter an instruction', 'warning');
      return;
    }

    if (isResponseBusy()) {
      loadingManager.showToast('A response is already in progress', 'warning');
      return;
    }

    submitBtn.disabled = true;

    try {
      // Fetch available skills for intent detection
      const skillsResp = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'getSkills' }, (response) => {
          if (chrome.runtime.lastError) resolve({ skills: [] });
          else resolve(response || { skills: [] });
        });
      });
      const availableSkills = skillsResp && skillsResp.skills ? skillsResp.skills : [];
      const skillsModule = await getChatSkills();

      // Detect skill intent from instruction
      const cmd = skillsModule.parseCommand(instruction, availableSkills);
      let requestedSkill = null;
      let effectiveInstruction = instruction;

      if (cmd.type === 'skill') {
        requestedSkill = cmd.skillName;
        effectiveInstruction = cmd.body || instruction;
      } else {
        const detectedSkill = skillsModule.detectSkillIntent(instruction, availableSkills);
        if (detectedSkill) {
          requestedSkill = detectedSkill.skillName;
          effectiveInstruction = detectedSkill.body || instruction;
        }
      }

      if (streamState.getMediaData() && streamState.getMediaData().base64) {
        // Media + instruction
        const mediaInfo = `[${streamState.getMediaData().type.toUpperCase()} loaded]`;

        // Show chat area and hide one-off instruction area
        oneoffInstructionArea.classList.add('hidden');
        chatMainArea.classList.remove('hidden');
        chatUI.addMessage('User', `${effectiveInstruction}\n\n[${mediaInfo}]`);
        if (requestedSkill) {
          chatUI.addMessage(
            'System',
            `🎯 Skill detected: **${requestedSkill}**. Loading skill instructions...`
          );
        }

        // Use orchestrator with media + skill
        await makeApiCallWithMedia(
          {
            instruction: effectiveInstruction,
            context: {
              type: 'media',
            },
          },
          streamState.getMediaData(),
          'auto',
          requestedSkill
        );

        instructionInput.value = '';
        selectedTextDiv.textContent = '';
        selectedText = null;
        clearCurrentMediaData();
      } else if (selectedText && selectedText.trim()) {
        // Text-only instruction
        const promptRequest = {
          instruction: effectiveInstruction,
          context: {
            type: 'selected_text',
            text: selectedText,
          },
        };

        // Show chat area and hide one-off instruction area
        oneoffInstructionArea.classList.add('hidden');
        chatMainArea.classList.remove('hidden');
        chatUI.addMessage(
          'User',
          `${effectiveInstruction}\n\n[Selected text: ${selectedText.substring(0, 50)}${selectedText.length > 50 ? '...' : ''}]`
        );
        if (requestedSkill) {
          chatUI.addMessage(
            'System',
            `🎯 Skill detected: **${requestedSkill}**. Loading skill instructions...`
          );
        }

        await makeApiCall(promptRequest, 'auto', requestedSkill);
        instructionInput.value = '';
        // Keep the selection sticky so further sidebar prompts can reuse it.
      } else if (hasConversation()) {
        // No selection/media, but a conversation exists — run as a follow-up.
        const promptRequest = {
          instruction: effectiveInstruction,
          context: {
            type: 'previous_response',
          },
        };

        oneoffInstructionArea.classList.add('hidden');
        chatMainArea.classList.remove('hidden');
        chatUI.addMessage('User', effectiveInstruction);
        if (requestedSkill) {
          chatUI.addMessage(
            'System',
            `🎯 Skill detected: **${requestedSkill}**. Loading skill instructions...`
          );
        }

        await makeApiCall(promptRequest, 'auto', requestedSkill);
        instructionInput.value = '';
      } else {
        loadingManager.showToast('Please select text or load media first', 'warning');
      }
    } catch (error) {
      if (error.name === 'AbortError') {
        chatUI.addMessage('System', 'Response stopped');
      } else {
        let errorMsg = error.message;
        if (error.details) {
          errorMsg += ` (Details: ${JSON.stringify(error.details)})`;
        }
        loadingManager.showToast('Error: ' + errorMsg, 'error');
        console.error('Error in one-off instruction submission:', error);
      }
      resetRunUi(RUN_STATES.IDLE);
      currentAbortController = null;
    } finally {
      submitBtn.disabled = false;
    }
  });

  // --- Pinned Instructions Functionality ---
  async function renderPinnedActions() {
    if (!pinnedActionsContainer) return;
    pinnedActionsContainer.innerHTML = ''; // Clear existing pinned actions

    try {
      const { pinnedQuickActions, instructions } = await new Promise((resolve, reject) => {
        chrome.storage.local.get(['pinnedQuickActions', 'instructions'], (result) => {
          if (chrome.runtime.lastError) {
            return reject(chrome.runtime.lastError);
          }
          resolve(result);
        });
      });

      const currentPins = pinnedQuickActions || [];
      const allInstructions = instructions || [];

      if (currentPins.length === 0) {
        return;
      }

      currentPins.forEach((pinId) => {
        const instruction = allInstructions.find((inst) => inst.id === pinId);
        if (instruction) {
          const button = document.createElement('button');
          const iconLetter = instruction.name ? instruction.name[0].toUpperCase() : '?';
          button.textContent = iconLetter;
          button.title = instruction.name; // Set full instruction name as tooltip
          button.classList.add('quick-action-button', 'pinned-action-item');
          button.dataset.instructionId = instruction.id; // Store ID
          // button.dataset.instructionContent = instruction.content; // Or store full content

          button.addEventListener('click', () => {
            // Retrieve the instruction object
            const instructionToExecute = allInstructions.find(
              (inst) => inst.id === button.dataset.instructionId
            );
            if (!instructionToExecute) {
              loadingManager.showToast('Error: Could not find instruction details.', 'error');
              return;
            }
            executeSelectedTextInstruction(instructionToExecute);
          });
          pinnedActionsContainer.appendChild(button);
        }
      });
    } catch (error) {
      console.error('Error rendering pinned actions:', error);
      loadingManager.showToast('Error loading pinned actions.', 'error');
    }
  }

  // Initial call to render and listener for changes will be added later.
  // The block for managePinnedActionsButton listener has been removed.

  // Initial rendering of pinned actions
  renderPinnedActions();

  // The chrome.storage.onChanged listener above has been updated to include this logic.
  // No need for a separate listener here.

  // Voice input functionality
  const voiceToggleButton = document.getElementById('voice-toggle-button');

  // Voice input initialization
  if (voiceToggleButton) {
    // Debounce wrapper for voice toggle to prevent rapid start/stop
    let lastVoiceToggleTime = 0;
    const VOICE_TOGGLE_DEBOUNCE_MS = 500; // 500ms debounce

    const debouncedToggleVoiceInput = async () => {
      const now = Date.now();
      if (now - lastVoiceToggleTime < VOICE_TOGGLE_DEBOUNCE_MS) {
        return;
      }
      lastVoiceToggleTime = now;
      const voice = await getChatVoice();
      voice.toggleVoiceInput(voiceToggleButton, userInput);
    };

    voiceToggleButton.addEventListener('click', debouncedToggleVoiceInput);
  }

  // Initialize voice input settings
  getChatVoice().then((voice) => {
    voice.syncVoiceInputSettings().then(() => {
      voice.updateVoiceToggleButtonState(voiceToggleButton);
    });

    // Clean up voice input on page unload
    window.addEventListener('beforeunload', function () {
      if (voice.getIsListening()) {
        voice.stopVoiceInput(voiceToggleButton, userInput);
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') {
        return;
      }

      if (changes['voiceInputEnabled'] || changes['voiceInputPermissionState']) {
        voice.syncVoiceInputSettings().then(() => {
          voice.updateVoiceToggleButtonState(voiceToggleButton);
        });
      }
    });
  });
}); // End of DOMContentLoaded
