# Chat DOX

## Purpose

The `src/chat/` subtree contains side panel chat modules imported by `chat.js`.

## Ownership

- `ChatUI.js` owns chat DOM rendering, message controls, and attachment previews.
- `ChatAPI.js` owns profile/config resolution and run bridge calls to the background worker.
- `ChatSkills.js` owns `/skills`, `/skill <name>`, per-skill shortcuts, natural-language skill intent detection, and the pure typeahead picker helpers (`buildSlashCandidates`, `filterSlashCandidates`).
- `ChatMedia.js` owns media validation, media prompts, base64 conversion, attachment sizing, and vision support checks.
- `ChatStream.js` owns streaming state tracking.
- `ChatVoice.js` owns speech recognition state and voice toggle behavior.
- `ChatPageActions.js` owns page-aware quick actions and preset analysis prompts.
- `ChatComposer.js` owns the composer-led UI: the visible context tray, the contextual quick-action row, and inline Stop/Retry/Edit/Continue recovery. It reads context from the DOM (tray item visibility, `data-run-state` on `#input-area`) and routes actions through handlers supplied by `chat.js`.

## Local Contracts

- Chat modules are imported from `chat.js`; tests expect every `src/chat/*.js` module to be referenced there.
- Source modules should stay under the current 600-line guard unless the test contract changes deliberately.
- Skill intent support must preserve the documented patterns in root AGENTS.md and `docs/SKILL_EXAMPLES.md`.
- Media handling must route image/video/audio requests through profile selection that supports vision when required.
- UI state changes that affect buttons, attachments, streaming, or storage sync must stay coordinated with `chat.js`.
- `ChatStream.js` run ID (`currentRunId`) is the authoritative ownership token for orchestrator events; `chat.js` checks it against `streamState.getRunId()` before processing any event.
- `ChatPageActions.js` returns structured `{instruction, context}` prompt request objects via `buildSmartPromptRequest`; callers pass these to `makeApiCall` which calls `composeUserPrompt` from `src/prompts.js`.
- Composer surfaces (`#context-tray`, `#quick-actions-row`, `#page-context-strip`) are the single visible context surface near the composer; `ChatComposer.js` keeps their visibility synchronized with strip state and the run-state contract from `src/utils/runState.js`.
- Inline recovery buttons (Stop/Retry/Edit/Continue) must route through the canonical run entry points (`stopApiRequest`, `runSelectedTextPrompt`, `makeApiCall`); Continue always builds on `previous_response` context, never on a stale sticky selection.

## Work Guidance

- Keep DOM selection and page-level event wiring in `chat.js` unless a module already owns the behavior.
- Keep pure formatting/parsing helpers exported for tests where possible.
- Preserve user-friendly error messages for runtime, permission, profile, and media failures.
- Update root docs or skill examples when chat command behavior changes.
- New prompt paths must return structured request objects; do not concatenate raw context strings.

## Verification

- Run `npm run test` after chat module changes.
- For UI, media, voice, or streaming changes, reload the side panel and exercise the affected flow in Chrome or Edge.

## Local Contracts

- `ChatGrounding.js` owns the sidebar `webSearchEnabled` toggle, background-only Brave key status bridge, safe `Sources` formatting, and nested tool-result classification. It must not read `braveSearchApiKey` from side-panel storage.
- `ChatGrounding.formatSourcesBlock()`, `buildBodyWithSources()`, and `buildFinalResponseBody()` are the canonical rendering helpers for grounded completions; source titles and URLs must be normalized before rendering.
- Tool traces must classify the inner payload of the orchestrator `{ success, result }` envelope so already-used, no-results, and failed searches are never displayed as successful executions.
- The reserved tool name `web_search` must never be shadowed by user-defined tools or imports; it is guarded in `ChatAPI.getTools()`, `RunOrchestrator._registerConfiguredTools()`, and Options save/import validation.
- When grounding is disabled, responses must remain identical to the pre-grounding behavior — no Sources section, no changed payload shape.
- Terminal response rendering consumes safe completion metadata; only confirmed token-limit exhaustion uses the token-budget warning, while reasoning-only responses may receive one bounded text-only recovery.

## Child DOX Index

- No child AGENTS.md files are currently needed under `src/chat/`.

## Work Guidance

- Keep `chat.js` under its enforced line guard; move composer wiring and helpers into `ChatComposer.js` and `ChatGrounding.js` rather than expanding the entry point.
- Grounding metadata travels only in terminal events and through `braveSearch.js` helpers — never carry the Brave key in LLM request payloads, events, or logs.
